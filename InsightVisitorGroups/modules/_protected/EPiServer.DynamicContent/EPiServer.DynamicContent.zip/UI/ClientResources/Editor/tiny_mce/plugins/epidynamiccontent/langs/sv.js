﻿tinymce.addI18n("sv.epidynamiccontent", {
    desc: "Dynamiskt innehåll"
});

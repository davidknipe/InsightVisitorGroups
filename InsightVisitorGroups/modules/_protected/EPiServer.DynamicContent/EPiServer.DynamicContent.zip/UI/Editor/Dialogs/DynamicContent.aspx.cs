using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using EPiServer.ClientScript;
using EPiServer.ClientScript.Events;
using EPiServer.Core.Html.StringParsing;
using EPiServer.DynamicContent;
using EPiServer.Framework.Localization;
using EPiServer.Personalization.VisitorGroups;
using EPiServer.PlugIn;
using EPiServer.Security;
using EPiServer.ServiceLocation;
using EPiServer.Shell;
using EPiServer.UI.Edit;

namespace EPiServer.UI.Editor.Dialogs
{
    /// <summary>
    /// This dialog belongs to the html editor and is shown when the user clicks the tool bar icon 'Insert Dynamic content'
    /// </summary>
    public partial class DynamicContent : EditContentWebFormsBase
    {
        private DynamicContentEditControl _adapterSettings = null;
        private IDynamicContentFactory _factory = ServiceLocator.Current.GetInstance<IDynamicContentFactory>();
        private static Regex _removeInsignificantWhitespace = new Regex(@"\s*[\r\n]+\s*", RegexOptions.Singleline);

        private static EPiServer.Logging.Compatibility.ILog _log = EPiServer.Logging.Compatibility.LogManager.GetLogger(typeof(DynamicContent));

        public Injected<LocalizationService> LocalizationService { get; set; }
        public Injected<IVisitorGroupRoleRepository> VisitorGroupRoleRepository { get; set; }
        public Injected<IVisitorGroupRepository> VisitorGroupRepository { get; set; }

        /// <summary>
        /// Loads a dynamic content if the dialog was opened with one selected.
        /// Loads a dynamic content if an adapter is selected in the dropdown list.
        /// Sets up the settings UI for this dynamic content adapter.
        /// </summary>
        protected override void OnInit(EventArgs e)
        {
            IDynamicContentBase content = null;
            LoadAdapterList();

            if (!IsPostBack)
            {
                GroupList.SetAvailableContentGroups(Request["allcontentgroups"], Request["contentgroup"]) ;
                if (!String.IsNullOrEmpty(Request["dynamicclass"]) && Request["state"] != null && !String.IsNullOrEmpty(Request["hash"]))
                {
                    // We're editing existing dynamic content
                    try
                    {
                        content = _factory.CreateDynamicContent(Request["dynamicclass"], Request["state"], Request["hash"], true);
                    }
                    catch
                    {
                        AdapterValidator.ErrorMessage = String.Format(Translate("/editor/tools/dynamiccontent/adaptersettingserror"), Request["dynamicclass"]);
                        AdapterValidator.IsValid = false;
                    }
                    GroupList.GroupList = Request["groups"];
                }
                else if (AdapterList.Items.Count == 2)
                {
                    // When there's only one type of dynamic content load that one by default
                    content = InstantiateAdapter(AdapterList.Items[1].Value);
                }
                else if (AdapterList.Items.Count <= 1)
                {
                    AdapterPanel.Visible = false;
                    AdapterValidator.IsValid = false;
                    AdapterValidator.ErrorMessage = Translate("/editor/tools/dynamiccontent/noplugins");
                }
                else if (!String.IsNullOrEmpty(Request.QueryString["SelectedPlugin"]))
                {
                    //Workaround for viewstate problem. When we do a postback and change the control structure
                    //(we load a different adapter) that is incompatible with the last structure we get a crash.
                    //But this "Hack" fixes the problem by refreshing the page with SelectedPlugin as parameter instead of doing postback.
                    content = InstantiateAdapter(Request.QueryString["SelectedPlugin"]);
                }
            }
            else if (!String.IsNullOrEmpty(Request[AdapterList.UniqueID]))
            {
                //We need to get the value from the dropdown list very early to be able to
                //set up content form the settingsform before it's to late.
                content = InstantiateAdapter(Request[AdapterList.UniqueID]);
            }

            if (content != null)
            {
                InitializeAdapter(content);
            }
            base.OnInit(e);
        }

        private void LoadAdapterList()
        {
            AdapterList.Items.Add(String.Empty);
            foreach (Type type in _factory.RegisteredTypes())
            {
                string adapter = _factory.Name(type);
                AdapterList.Items.Add(new ListItem(GetAdapterDisplayName(adapter), adapter));
            }
        }

        private IDynamicContentBase InstantiateAdapter(string adapterName)
        {
            return _factory.InstantiateDynamicContent(adapterName);
        }

        private void InitializeAdapter(IDynamicContentBase content)
        {
            AdapterDescription.Text = GetAdapterDescription(content.GetType());

            _adapterSettings = CreateAdapterSettings(content);
            if (_adapterSettings != null)
            {
                _adapterSettings.DynamicContent = content;
                AdapterSettingsContainer.Controls.Add(_adapterSettings);
                OkButton.Enabled = true;

                if (_adapterSettings is DynamicContentSettings)
                {
                    ((DynamicContentSettings)_adapterSettings).Initialize();
                }
            }
        }

        /// <summary>
        /// Populates the dropdown list with available adapters.
        /// If a dynamic content is selected when the dialog is opended, that adapter will be selected.
        /// </summary>
        protected override void OnLoad(EventArgs e)
        {
            Title = Translate("/editor/tools/dynamiccontent/toolheading");

            if (!IsPostBack)
            {
                if (_adapterSettings != null && _adapterSettings.DynamicContent != null)
                {
                    AdapterList.Items.FindByValue(_factory.Name(_adapterSettings.DynamicContent.GetType())).Selected = true;
                }
            }

            // Panels visibility
            bool pluginSelected = _adapterSettings != null;
            DescriptionPanel.Visible = pluginSelected;
            SettingsPanel.Visible = pluginSelected;
            VisitorPanel.Visible = pluginSelected;

            base.OnLoad(e);
        }

        protected void OnOkClick(object sender, EventArgs e)
        {
            IDynamicContentControlAdapter adapter = _adapterSettings.DynamicContent as IDynamicContentControlAdapter;

            //PrepareToSave needs to be run, to validate the properties.
            _adapterSettings.PrepareForSave();

            if (adapter != null && !adapter.Properties.Any(p => p.IsModified))
            {
                //If PrepareForSave in edit control for dynamic content has not modified properties it has probably
                //set value on the typed dynamic content control. Transfer values from control to Properties.
                MethodInfo method = typeof(DynamicContentEditControl).GetMethod("GetDynamicContentInstance");
                MethodInfo genericMethod = method.MakeGenericMethod(adapter.ControlType);
                Control ctrl = genericMethod.Invoke(_adapterSettings, null) as Control;
                if (ctrl != null)
                {
                    adapter.TransferDataFromControlToProperties(ctrl);
                }
            }

            //Validate content group and visitor group settings
            GroupList.Validate(false);

            Validate();

            if (IsValid)
            {
                ScriptManager.AddEventListener(Page, new CustomEvent(EventType.Load, "OkClick"));
            }
        }

        private Type GetWrappedType(IDynamicContentBase dynamicContent)
        {
            Type type = dynamicContent.GetType();
            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(DynamicContentAdapter<>))
            {
                return type.GetGenericArguments()[0];
            }
            return type;
        }

        /// <summary>
        /// Creates a control for changing the dynamic content adapter settings.
        /// </summary>
        /// <remarks>
        /// If the dynamic content adapter has a custom settings control defined, it will be created.
        /// If not, a genereic settings control will be created.
        /// </remarks>
        /// <param name="dynamicContent">The dynamic content.</param>
        /// <returns>A control used to change the settings for a dynamic content.</returns>
        private DynamicContentEditControl CreateAdapterSettings(IDynamicContentBase dynamicContent)
        {
            var url = Paths.ToResource(typeof(DynamicContent), "UI/Edit/DynamicContentSettings.ascx");
            var plugInDescriptor = PlugInDescriptor.Load(GetWrappedType(dynamicContent));
            var dynamicContentAttribute = plugInDescriptor.GetAttributes().FirstOrDefault(attribute =>
            {
#pragma warning disable CS0618
                var guiAttribute = attribute as GuiPlugInAttribute;
                return guiAttribute != null && guiAttribute.Area == PlugIn.PlugInArea.DynamicContent && !string.IsNullOrEmpty(guiAttribute.Url);
#pragma warning disable CS0618
            }) as GuiPlugInAttribute;

            if (dynamicContentAttribute != null)
            {
                url = dynamicContentAttribute.Url;
            }

            try
            {
                return (DynamicContentEditControl)Page.LoadControl(url);
            }
            catch (Exception e)
            {
                CustomValidator customValidator = new CustomValidator();
                customValidator.ErrorMessage = String.Format(Translate("/editor/tools/dynamiccontent/adaptersettingserror"), url);

                if (PrincipalInfo.Current.IsPermitted(SystemPermissions.DetailedErrorMessage))
                {
                    customValidator.ErrorMessage += string.Format("<br />{0}", e.ToString());
                }

                customValidator.IsValid = false;
                AdapterSettingsContainer.Controls.Add(customValidator);

                _log.Error(string.Format("Could not load DynamicContent [{0}]", url), e);
            }
            return null;
        }

        private bool GenerateDynamicContentWithPreview
        {
            get
            {
                string generatePreview = Request.QueryString["generatepreview"];
                return generatePreview == null || Boolean.Parse(generatePreview);
            }
        }

        /// <summary>
        /// Gets the markup for the dynamic content.
        /// </summary>
        /// <value>The dynamic content markup.</value>
        protected string DynamicContentMarkup
        {
            get
            {
                if (_adapterSettings != null)
                {
                    string markup;

                    IEnumerable<string> visitorGroups = GroupList.GroupList.Split(new char[] {','}, StringSplitOptions.RemoveEmptyEntries);

                    VisitorGroupMarkupGenerator groupResolver = new VisitorGroupMarkupGenerator(VisitorGroupRepository.Service, VisitorGroupRoleRepository.Service, GroupList.ContentGroup, visitorGroups, LocalizationService.Service);
                    if (GenerateDynamicContentWithPreview)
                    {
                        markup = _factory.GetMarkupForEditor(_adapterSettings.DynamicContent, true, groupResolver);
                    }
                    else
                    {
                        markup = _factory.GetMarkup(_adapterSettings.DynamicContent, true, groupResolver);
                    }

                    //Replacing ' because it's used as a string through a javascript call that fails to close correctly otherwise
                    markup = markup.Replace("'", "&#39;");
                    // Remove any newline and all surrounding space characters since they will break javascript.
                    return _removeInsignificantWhitespace.Replace(markup, " ").Trim();
                }
                return String.Empty;
            }
        }

        /// <summary>
        /// Gets the translated display name according to the current language.
        /// </summary>
        /// <returns>The translated display name.</returns>
        /// <remarks>If no translation is found the name in Web.config will be used.</remarks>
        private string GetAdapterDisplayName(string name)
        {
            return TranslateFallback(String.Format("/dynamiccontenttypes/dynamiccontent[@name=\"{0}\"]/caption", name), name);
        }

        /// <summary>
        /// Gets the translated description according to the current language.
        /// </summary>
        /// <returns>The translated display name.</returns>
        /// <remarks>If no translation is found the description in Web.config will be used.</remarks>
        private string GetAdapterDescription(Type type)
        {
            string fallbackDescription = _factory.Description(type);
            string name = _factory.Name(type);
            return TranslateFallback(String.Format("/dynamiccontenttypes/dynamiccontent[@name=\"{0}\"]/description", name), fallbackDescription);
        }
    }
}
